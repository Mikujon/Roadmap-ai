import { getAuthContext } from "@/lib/auth";
import { redirect } from "next/navigation";
import ProjectGovernanceClient from "./GovernanceClient";
export default async function Page({ params }: { params: { id: string } }) {
  const ctx = await getAuthContext();
  if (!ctx) redirect("/sign-in");
  return <ProjectGovernanceClient projectId={params.id} />;
}
